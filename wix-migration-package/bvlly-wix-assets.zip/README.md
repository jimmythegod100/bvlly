# Assets for Wix Media Manager

Upload this folder (or the parent `bvlly-wix-assets.zip`) into Wix Media Manager.

| Folder / file | Contents |
| --- | --- |
| `lookbook/` | On-body product photos used on the live site |
| `brand/` | Mascot PNG + SVG |
| `og.jpg` | Open Graph / social share |
| `favicon.svg` | Favicon |

Image paths in `content/products.csv` are relative to this `assets/` root (e.g. `lookbook/beware-hood-black.jpg`).

Fonts are Google Fonts (Outfit, UnifrakturMaguntia) — add them in Wix Text settings; they are not in this zip.
